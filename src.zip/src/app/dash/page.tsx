import React from 'react'
import module from "./p.module.css"

import { IoArrowRedoSharp } from "react-icons/io5";
const page = () => {
  return (

      <div className={module.block}>
          <h1 className={module.b}>Dashboard:</h1>
          <div className={module.inl}>
              <div className={module.div1}>
                 <h1 className={module.h}>vendée</h1>
                 <h3 className={module.hh}>(budget)</h3>
                 <div className={module.interdiv}>
                     <h1 className={module.hhh}>13 000 DT</h1>
                     <img  src="/mon.jpg" className={module.img1}/>
                 </div>
                 </div>
                 <div className={module.div2}>
                 <h1 className={module.h} style={{color:"blue"}}>echange</h1>
                 <h3 className={module.hh} style={{color:"orangered"}}>(nombre)</h3>
                 <div className={module.interdiv}>
                     <h1 className={module.hhh} style={{color:"blue"}}>48</h1>
                     <img  src="/nom2.jpg" className={module.img2}/>
                 </div>
                 </div>
                           <div className={module.div2} style={{backgroundColor:"#F34E1E" ,width:"500px", border:"#F34E1E"}}>
                 <h1 className={module.h} style={{color:"white"}}>don</h1>
                 <h3 className={module.hh} style={{color:"gary"}}>(nombre)</h3>
                 <div className={module.interdiv}>
                     <h1 className={module.hhh} style={{color:"white"}}>130</h1>
                     <img  src="/nom3.jpg" className={module.img2}/>
                 </div>
                 </div>
            
           
              
          </div>
          <div className={module.in}>
<div className={module.div3}>
<div className={module.k}>
    <h1 className={module.p}>Mes dernier offre publilics </h1><button className={module.pp}> consulter</button>
    
    </div>
    <h3 className={module.hh} style={{color:"orangered"}}>(nombre)</h3><div className={module.o}>
    <img  src="/nom4.jpg" className={module.img4}/> <div>
      <div className={module.oo}> <h1 className={module.kk}>
            endurce
        </h1 >
        <h1 className={module.kkk}>
            livfre math
        </h1>
        </div> 
    </div>
    <h1 className={module.kkkK}>20 dt</h1>
    <IoArrowRedoSharp className={module.kkkKK} />

    </div>
    <hr className={module.hr}/>
    <div className={module.o}>
    <img  src="/nom4.jpg" className={module.img4}/> <div>
      <div className={module.oo}> <h1 className={module.kk}>
            endurce
        </h1 >
        <h1 className={module.kkk}>
            livfre math
        </h1>
        </div> 
    </div>
    <h1 className={module.kkkK}>20 dt</h1>
    <IoArrowRedoSharp className={module.kkkKK} />

    </div>
    <hr className={module.hr}/>
    <div className={module.o}>
    <img  src="/nom4.jpg" className={module.img4}/> <div>
      <div className={module.oo}> <h1 className={module.kk}>
            endurce
        </h1 >
        <h1 className={module.kkk}>
            livfre math
        </h1>
        </div> 
    </div>
    <h1 className={module.kkkK}>20 dt</h1>
    <IoArrowRedoSharp className={module.kkkKK} />

    </div>
    
</div>
<div className={module.div4}>       
<div className={module.i}>
      <img src="nom5.jpg" className={module.fim} alt="Descriptive text" />
    </div></div>

          </div>
          
      </div>
   
  )
}

export default page

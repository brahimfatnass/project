"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { FaAngleDown } from "react-icons/fa";
import { FaLaptopCode } from "react-icons/fa";
import { FaLaptopHouse } from "react-icons/fa";
import { IoTicketOutline } from "react-icons/io5";
import { FaCartPlus } from "react-icons/fa6";
import { FiMessageCircle } from "react-icons/fi";
import { FaGem } from "react-icons/fa";
import module from './p.module.css';
import Rt from "../../devpro/page";
import Rtt from "../../devpro/log/page";

const Nav = () => {
  const [isNvVisible, setIsNavVisible] = useState(false);

  const handleClick = () => {
    setIsNavVisible(!isNvVisible); // Toggle visibility
  };
  const handleClickk = () => {
    setIsNavVisible(!isNvVisible); // Toggle visibility
  };

  return (
    <div className={module.navbar}>
      {isNvVisible && <Rt />}
      {isNvVisible && <Rtt />}
      <nav className={module.nav}>
        <div className={module.div}>
          <ul className={module.links}>
            <li className={module.containe}>
              <Link href="/" className={module.link}>
                <span className={module.linkContent}>
                  <span className={module.logoPlaceholder}></span>
                  <span className={module.text}>Home</span>
                </span>
              </Link>
            </li>
            <li className={module.containe}>
              <Link href="/dash" className={module.link}>
                <span className={module.linkContent}>
                  <FaLaptopCode className={module.logo} />
                  <h3 className={module.text}>Dashboard</h3>
                </span>
              </Link>
            </li>
            <li className={module.con}>
              <Link href="/" className={module.link}>
                <span className={module.linkContent}>
                  <FaLaptopHouse className={module.logo} />
                  <span className={module.text}>Fil d'actualité</span>
                  <FaAngleDown className={module.logob} />
                </span>
              </Link>
              <ul className={module.ul}>
                <li><Link href="/g/ii" className={module.class}>etudiant</Link></li>
                <li><Link href="/g/i" className={module.class}>societe</Link></li>
                <li><Link href="/g/h" className={module.class}>grosiste</Link></li>
                <li><Link href="/g/o" className={module.class}>espace etudiant</Link></li>
              </ul>
            </li>
            <li className={module.conc}>
              <Link href="/of" className={module.link}>
                <span className={module.linkContent}>
                  <IoTicketOutline className={module.logo} />
                  <span className={module.text}>Mes offres</span>
                </span>
              </Link>
              <ul className={module.ul}>
                <li><Link href="../compo/comp6" className={module.class}>....tarif....</Link></li>
              </ul>
            </li>
            <li className={module.containe}>
              <Link href="/g/t" className={module.link}>
                <span className={module.linkContent}>
                  <FaCartPlus className={module.logo} />
                  <span className={module.text}>Mes demandés</span>
                </span>
              </Link>
            </li>
            <li className={module.containe}>
              <Link href="/fac" className={module.link}>
                <span className={module.linkContent}>
                  <FiMessageCircle className={module.logo} />
                  <span className={module.text}>Mes contacts</span>
                </span>
              </Link>
            </li>
            <li className={module.containe}>
              <Link href="/conta" className={module.link}>
                <span className={module.linkContent}>
                  <button className={module.button}>
                    <FaGem className={module.logob} />
                    <span className={module.text}>devenir pro</span>
                  </button>
                </span>
              </Link>
            </li>
          </ul>

          <div className={module.a}>
            <Link href="/" className={module.aa} onClick={handleClick}>Login</Link>
            <Link href="/" className={module.uu}  onClick={handleClickk}>Sign-up</Link>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Nav;
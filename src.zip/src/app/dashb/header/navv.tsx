
import Link from 'next/link';
import { FaAngleDown } from "react-icons/fa";
import { AiFillAlipayCircle } from "react-icons/ai";
import { FaLaptopCode } from "react-icons/fa";
import { FaLaptopHouse } from "react-icons/fa";
import { IoTicketOutline } from "react-icons/io5";
import { FaCartPlus } from "react-icons/fa6";
import { FiMessageCircle } from "react-icons/fi";
import { FaGem } from "react-icons/fa";
import { PiLineVerticalLight } from "react-icons/pi";
import { TbLayoutSidebarRightExpandFilled } from "react-icons/tb";
import { HiOutlineSearchCircle } from "react-icons/hi";
import { GiShoppingCart } from "react-icons/gi";
import module from './p.module.css';

const navv = () => {

  
  return (
    <div>
      
      {/* Rest of your HTML */}
      <div className={module.div4}>
        <h1 className={module.title}>Sponsoris:</h1>
        <div className={module.sponsorContainer}>
          {/* Sponsor Card 1 */}
          <div className={module.card}>
            <div className={module.po}>
              <img src="/b.jpeg" alt="Description of image" className={module.image3} />
            </div>
            <div className={module.po}>
              <div className={module.poo}>
                <h1 className={module.o}>librairie:</h1>
                <div className={module.oo}>fdg</div>
                <p className={module.ooo}>io</p>
              </div>
            </div>
          </div>
        </div>
        {/* Sponsor Card 2 */}
        <div className={module.sponsorContainer}>
          <div className={module.card}>
            <div className={module.po}>
              <img src="/b.jpeg" alt="Description of image" className={module.image3} />
            </div>
            <div className={module.po}>
              <div className={module.poo}>
                <h1 className={module.o}>librairie:</h1>
                <div className={module.oo}>fdg</div>
                <p className={module.ooo}>io</p>
              </div>
            </div>
          </div>
          <ul className={module.y}>
            <li className={module.ll}>uiuuuuuu</li>
            <li className={module.l}>uiuuuuuuuuuuuuuuuuuu</li>
            <li className={module.l}>uiuuuuuuuuuuuuuuuuuu</li>
            <li className={module.l}>uiuiuuuuuuuuuuuuuuuuuu</li>
            <li className={module.l}>uiuiuuuuuuuuuuuuuuuuuu</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default navv

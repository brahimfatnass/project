import { IoArrowRedoSharp } from "react-icons/io5";
import React from 'react'
import module from "./p.module.css"
const hpage = () => {
  return (
    <div className={module.div}>
      <div className={module.ii}>
        <img src="/brahim.jpg" className={module.image}/>
        <div className={module.i}>
          <h1 className={module.c}>garderie scolaire</h1>
          <h3 className={module.cc}>tunis</h3>
        <p className={module.y} >Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita modi delectus consequuntur, eos sequi illo maiores totam sapiente aperiam ducimus dolores assumenda numquam earum itaque suscipit aspernatur est magnam reiciendis.++</p>
        <button className={module.yy}>consulter--></button>
        </div>
      </div>

      
    </div>
  )
}

export default hpage

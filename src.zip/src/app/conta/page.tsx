"use client";
import React from 'react';
import './p.css'; // Import the CSS file
import Cmp from "./NAF/page";

const UserProfile = () => {
  const handleModifier = () => {
    console.log('Modifier cliqué');
  };

  const handleReset = () => {
    console.log('Reinitialisation cliqué');
  };

  const handleSave = () => {
    console.log('Enregistrer cliqué');
  };

  return (
    <div className="profile-container">
      {/* Personal Information Section */}
      <section className="profile-section">
        <div className="detail-block">
          <img src="./brahim.jpg" alt="Profile" className="profile-image" />
          <div className="input-group">
            <div className="input-pair">
              <span className="label">Nom :</span>
              <input type="text" className="value" />
              <span className="label">Prenom :</span>
              <input type="text" className="value" />
            </div>
          </div>
        </div>

        <div className="detail-block">
          <div className="input-group">
            <div className="input-pair">
              <span className="label">Telephone :</span>
              <input type="text" className="value" />
              <span className="label">Adresse :</span>
              <input type="text" className="value" />
            </div>
          </div>
        </div>

        <button className="modifier-button" onClick={handleModifier}>Modifier</button>
      </section>

      {/* Professional Account Section */}
      <section className="pro-account-section">
        <h2 className="pro">Devenir un compte pro :</h2>
        <div className="flex-detail-block">
          <span className="label">Domaine :</span>
          <select className="u">
            <option value="">Sélectionnez un domaine</option>
            <option value="domaine1">Domaine 1</option>
            <option value="domaine2">Domaine 2</option>
            <option value="domaine3">Domaine 3</option>
          </select>
        </div>
        <div className="flex-detail-block">
          <span className="label">Company Name :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="flex-detail-block">
          <span className="label">Company Identifier :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="flex-detail-block">
          <span className="label">Director Name :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="flex-detail-block">
          <span className="label">Main Category :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="flex-detail-block">
          <span className="label">Sub Category :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="flex-detail-block">
          <span className="label">Province :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="flex-detail-block">
          <span className="label">Address :</span>
          <input type="text" className="value-input" />
        </div>
        <div className="map-container">
  <iframe
    src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d42678.78887745934!2d10.137758935337025!3d36.89184374212519!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sar!2stn!4v1737224256804!5m2!1sar!2stn"
    style={{ border: 0 }}
    allowFullScreen=""
    loading="lazy"
    referrerPolicy="no-referrer-when-downgrade"
  ></iframe>
</div>
        <div className="action-buttons">
          <button className="reset-button" onClick={handleReset}>Reinitialisation</button>
          <button className="save-button" onClick={handleSave}>Enregistrer</button>
        </div>
      </section>

      <Cmp/>
     
    </div>
  );
};

export default UserProfile;
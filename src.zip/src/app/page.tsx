import React from 'react';
import './App.css';

function App() {
  return (
    <div className="app">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1>Save, Organize, and Access Your Links Anytime</h1>
          <p>LinkBook helps you store and manage your favorite links in one place.</p>
          <div className="search-bar">
            <input type="text" placeholder="Paste your link here..." />
            <button className="btn save-link">Save Link</button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="features">
        <h2>Why Choose LinkBook?</h2>
        <div className="feature-cards">
          <div className="card">
            <h3>📁 Organized</h3>
            <p>Create folders and categories to keep your links tidy.</p>
          </div>
          <div className="card">
            <h3>🔒 Secure</h3>
            <p>Your links are safe with our encryption technology.</p>
          </div>
          <div className="card">
            <h3>🌐 Access Anywhere</h3>
            <p>Access your links from any device, anytime.</p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="how-it-works">
        <h2>How It Works</h2>
        <div className="steps">
          <div className="step">
            <span>1</span>
            <p>Sign up for a free account.</p>
          </div>
          <div className="step">
            <span>2</span>
            <p>Save your links with one click.</p>
          </div>
          <div className="step">
            <span>3</span>
            <p>Organize and access them anytime.</p>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="pricing">
        <h2>Pricing</h2>
        <div className="pricing-cards">
          <div className="card">
            <h3>Free</h3>
            <p className="price">$0/month</p>
            <ul>
              <li>Save up to 100 links</li>
              <li>Basic organization</li>
              <li>Ads supported</li>
            </ul>
            <button className="btn">Get Started</button>
          </div>
          <div className="card">
            <h3>Pro</h3>
            <p className="price">$5/month</p>
            <ul>
              <li>Unlimited links</li>
              <li>Advanced organization</li>
              <li>No ads</li>
            </ul>
            <button className="btn">Go Pro</button>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;
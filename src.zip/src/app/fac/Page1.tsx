import React from 'react'

const Page1 = () => {
  return (
    <div>
      paage 1ljmk
    </div>
  )
}

export default Page1

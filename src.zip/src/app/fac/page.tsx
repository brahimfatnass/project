"use client";
import React, { useState } from "react";
import module from "./p.module.css";
import Page1 from './Page1'
import Page2 from './page2'
import Na from "./NAF/page"; 
const HPage = () => {
  const [content, setContent] = useState(null); 

  return (
    <div className={module.i}>
      <div className={module.ii}>
        {/* Premier élément */}
        <div
          className={module.uu}
          onClick={() => setContent(<Page1 />)} // Afficher Page1 dans la section supplémentaire
        >
          <img src="/brahim.jpg" alt="Profile" className={module.image} />
          <div className={module.u}>
            <h1 className={module.c}>brahim fatnassi</h1>
            <div className={module.ooo}>
              <h1 className={module.c}>13:11</h1>
              <h1 className={module.o}>2</h1>
            </div>
            <h3 className={module.cc}>25631585</h3>
            <p className={module.y}>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita modi delectus.++
            </p>
          </div>
        </div>
        <hr />

        {/* Deuxième élément */}
        <div
          className={module.uu}
          style={{ backgroundColor: "white", marginTop: "20px" }}
          onClick={() => setContent(<Page2 title="brahim" />)} // Afficher Page2 dans la section supplémentaire
        >
          <img src="/brahim.jpg" alt="Profile" className={module.image} />
          <div className={module.u}>
            <h1 className={module.c}>brahim fatnassi</h1>
            <div className={module.ooo}>
              <h1 className={module.c}>13:11</h1>
              <h1 className={module.o}>2</h1>
            </div>
            <h3 className={module.cc}>25631585</h3>
            <p className={module.y}>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita modi delectus.++
            </p>
          </div>
        </div>
        <hr />

        {/* Troisième élément */}
        <div
          className={module.uu}
          style={{ backgroundColor: "white", marginTop: "20px" }}
          onClick={() => setContent(<Page3 />)} // Afficher Page3 dans la section supplémentaire
        >
          <img src="/brahim.jpg" alt="Profile" className={module.image} />
          <div className={module.u}>
            <h1 className={module.c}>brahim fatnassi</h1>
            <div className={module.ooo}>
              <h1 className={module.c}>13:11</h1>
              <h1 className={module.o}>2</h1>
            </div>
            <h3 className={module.cc}>25631585</h3>
            <p className={module.y}>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita modi delectus.++
            </p>
          </div>
        </div>
      </div>
      <hr />

      {/* Section supplémentaire */}
      <div className={module.iii}>
        {content || <Page2/>} {/* Afficher le contenu ou "hello world" par défaut */}
      </div>
      <Na />
    </div>
  );
};

export default HPage;
import { IoArrowRedoSharp } from "react-icons/io5";
import React from 'react'
import module from "./p.module.css";
const hpage = () => {
  return (
    <div className={module.div}>
      <div className={module.ii}>
        <img src="/brahim.jpg" className={module.image}/>
        <div className={module.i}>
          <h1 className={module.c}>livre 3eme anne</h1>
          <h3 className={module.cc}>sfax</h3>
        </div>
      </div>
      <div  className={module.uu}>
        <div className={module.u}>

          <img src="/nom4.jpg" className={module.image1}/>
          <h1 className={module.h}>endut</h1>
          <h1 className={module.hh}>livre math </h1>
          <p className={module.hhh}>desqeqsdqdqqqqqqqq</p>
        
          <IoArrowRedoSharp className={module.k} />
        </div>
        <div className={module.u}>

<img src="/o.jpg" className={module.image1}/>
<h1 className={module.h}>endut</h1>
<h1 className={module.hh}>sac a ddos </h1>
<p className={module.hhh}>desqeqsdqdqqqqqqqq</p>

<IoArrowRedoSharp className={module.k} />
</div>
<div className={module.u}>

<img src="/nom4.jpg" className={module.image1}/>

<h1 className={module.hh}  style={{marginTop:"15px"}}>livre math </h1>
<p className={module.hhh}>desqeqsdqdqqqqqqqq</p>

<IoArrowRedoSharp className={module.k} />
</div>
      </div>
      <button className={module.yy}>consulter--></button>
    </div>
  )
}

export default hpage

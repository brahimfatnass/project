import React from 'react'
import module from "./a.module.css"
import Cmp from "./com/page"
import Na from "../../dashb/header/navv"; 
import Amp from "../../compo/comp2/page"
const page = () => {
  return (
    <div className={module.div}>
      <h1>fil d'actualite:</h1>
<Cmp/>
<Amp/>
<Cmp/>
<Na/>
    </div>
  )
}

export default page

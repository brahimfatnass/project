import { IoArrowRedoSharp } from "react-icons/io5";
import React from 'react'
import module from "./p.module.css"
import { GiShoppingCart } from "react-icons/gi";
const hpage = () => {
  return (
    <div className={module.div}>
      <div className={module.ii}>
        <img src="/brahim.jpg" className={module.image}/>
        <div className={module.i}>
          <h1 className={module.c}>brahim fatnassi</h1>
          <h3 className={module.cc}>bizerte</h3>
        </div>
      </div>
      <div  className={module.uu}>
        <div className={module.uuu}>

          <img src="/nom4.jpg" className={module.image1}/>
          
        </div>
        <div className={module.u}>


<h1 className={module.h}>endut</h1>
<h1 className={module.hh}>livre 3 emme anne </h1>
<hr/>
<h2 className={module.hhhh}>5000 dt</h2>
<div className={module.x}>ACHETER<GiShoppingCart className={module.xx} /></div>
</div>


      </div>
    </div>
  )
}

export default hpage

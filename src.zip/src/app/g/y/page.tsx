import React from 'react'
import module from "./a.module.css";
import Cmp from "./comp5/page"
import Cmp1 from "./comp2/page"
import Op from "../../compo/comp3/page"
import Navv from "../../dashb/header/navv"
import { MdAccessTime } from "react-icons/md";
const page = () => {
  return (
    <div className={module.div}>
      <h1 className={module.dii}>livres math:</h1>
      <h2 className={module.di}> <MdAccessTime /> 13h</h2>
      <Cmp/>
      <Cmp1 className="bg-white" />
      <Navv/>
      <Op/>
      <Op/>
      <Op/>
    </div>
  )
}

export default page

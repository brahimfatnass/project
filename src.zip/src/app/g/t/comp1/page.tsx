import { IoArrowRedoSharp } from "react-icons/io5";
import React from 'react'
import module from "./p.module.css"
const hpage = () => {
  return (
    <div className={module.div}>
    
      
      <div  className={module.uu}>
        <div className={module.u}>

          <img src="/nom4.jpg" className={module.image1}/>
          <h1 className={module.h}>endut</h1>
          <h1 className={module.hh}>livre 3eme anne </h1>
          <p className={module.hhh}>desqeqsdqdqqqqqqqq</p>
        
          <IoArrowRedoSharp className={module.k} />
        </div>
        <div className={module.u}>

<img src="/nom4.jpg" className={module.image1}/>
<h1 className={module.h}>endut</h1>
<h1 className={module.hh}>livre 3eme anne </h1>
<p className={module.hhh}>desqeqsdqdqqqqqqqq</p>

<IoArrowRedoSharp className={module.k} />
</div>

      </div>
    </div>
  )
}

export default hpage

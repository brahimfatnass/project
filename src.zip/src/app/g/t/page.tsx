import React from 'react'
import module from "./p.module.css"
import Ei from './comp1/page';
import { MdDisplaySettings } from "react-icons/md";
import { Module } from 'module';
const page = () => {
  return (
    <div className={module.div}>
      <div className={module.divv}>
      <div className={module.d}>
        
          <select name="" className={module.sel} >
              <option value="">livre</option>
              <option value="">i</option>
              <option value="">ii</option>
              <option value="">ii</option>
          </select>
          <select name="" className={module.sel} >
              <option value="">sfax</option>
              <option value="">i</option>
              <option value="">ii</option>
              <option value="">ii</option>
          </select>
  
          <button className={module.b}>reintilisation</button>
          <MdDisplaySettings  className={module.l}/>
          </div>
          <Ei/>
          <Ei/>
          <Ei/>
      </div>
      <div>
      <iframe
    src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d42678.78887745934!2d10.137758935337025!3d36.89184374212519!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sar!2stn!4v1737224256804!5m2!1sar!2stn"
    style={{ border: 0 }}
    allowFullScreen=""
    loading="lazy"
 className={module.iframe}
    referrerPolicy="no-referrer-when-downgrade"
  ></iframe>
      </div>

    </div>
  )
}

export default page
